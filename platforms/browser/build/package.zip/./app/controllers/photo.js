(function() {
    'use strict';

    angular
        .module('app')
        .controller('PhotoController', PhotoController);

    // Dependencias
    PhotoController.$injector = ['$scope'];

    function PhotoController($scope){

        // Lógica aqui
        // ...

        $scope.msg = "Foto";


        var watermark;
        var canvasDom;
        var canvas;

        var img = new Image();
        img.src = "photo1.jpg";

        //Create a watermark image object
        watermark = new Image();
        watermark.src = "";

        var larguraImagem = window.innerWidth;
        var alturaImagem = (img.height * window.innerWidth)/img.width;

        canvasDom = document.getElementById('canvas');
        canvasDom.width = larguraImagem;
        canvasDom.height = alturaImagem;

        canvas = canvasDom.getContext("2d");

        alert("width: " + img.width + "height: " + img.height)
        alert("width: " + window.innerWidth + "height: " + window.innerHeight);



        var larguraImagem = window.innerWidth;
        var alturaImagem = (img.height * window.innerWidth)/img.width;

        canvas.drawImage(img, 0, 0, larguraImagem, alturaImagem);

        







        //
        //
        //
        // navigator.camera.getPicture(onSuccess, onFail, { quality: 25,
        //     destinationType: Camera.DestinationType.DATA_URL
        // });
        //
        // function onSuccess(imageData) {
        //
        //     var img = new Image();
        //     img.src = "data:image/jpeg;base64," + imageData;
        //     canvas.canvasDom.width = img.width;
        //     canvas.canvasDom.height = img.height;
        //
        //     img.onload = function(e) {
        //         // canvas.drawImage(watermark, 0, 0);
        //         canvas.drawImage(img, 0, 0, img.width, img.height);
        //         canvas.font = "30px Arial";
        //         canvas.fillText("SergioD", 10, 50);
        //
        //     }
        //
        //     // var image = document.getElementById('myImage');
        //     // image.src = "data:image/jpeg;base64," + imageData;
        // }
        //
        // function onFail(message) {
        //     alert('Failed because: ' + message);
        // }


        //fim ImageController
    }

})();
